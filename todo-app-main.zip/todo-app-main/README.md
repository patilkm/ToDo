# todo-app
Simple todo app that uses localStorage.
